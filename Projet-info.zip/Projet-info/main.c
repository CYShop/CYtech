#include "header.h"

int main() {
    const char* filepath ="Logo.txt";
    includeFile(filepath);
    const char* title = "Bienvenue chez Luxury Porsche";
    printTitle(title);

    // Initialiser les tableaux de produits et de clients
    Product products[100];
    int numProducts = 0;

    Client clients[100];
    int numClients = 0;

    // Lire les données du produit et du client à partir des fichiers
    readProductData(products, &numProducts);
    readClientData(clients, &numClients);

    // Boucle principale du programme
    mainLoop(products, &numProducts, clients, &numClients);

    return 0;
}