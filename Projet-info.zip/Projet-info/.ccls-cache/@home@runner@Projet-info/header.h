#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

// Définir les structures pour le produit et le client

typedef struct {
    char name[50];
    int refNum;
    int quantity;
    int price;
    int size;
} Product;

typedef struct {
    int id;
    char name[50];
    char firstName[50];
    int balance;
    int numPurchases;
    int purchaseHistory[3];
    int cart[3]; // Panier de consommation
    int cartQuantities[3]; // Quantité des produits dans le panier
    int numItemsInCart; // Nombre d'articles dans le panier
} Client;

void printTitle(const char* title);
void readProductData(Product *products, int *numProducts);
void writeProductData(Product *products, int numProducts);
void displayStock(Product *products, int numProducts);
void updateStock(Product *products, int *numProducts);
void checkStockSpace(Product *products, int numProducts, int maxSpace);
void readClientData(Client *clients, int *numClients);
void writeClientData(Client *clients, int numClients);
int checkClientID(Client *clients, int numClients, int id);
void addNewClient(Client *clients, int *numClients);
int findClientByID(Client *clients, int numClients, int id);
void removeClient(Client *clients, int *numClients, int clientID);
void displayPurchaseHistory(Client *clients, int numClients, int clientID);
void buyProduct(Product *products, int numProducts, Client *clients, int clientID);
void removeProductFromCart(Client *client);
void checkout(Client *client, Product *products, int numProducts);
void addNewProduct(Product *products, int *numProducts);
void displayCart(Product *products, int numProducts, Client *client);
void removeAccount(Client *clients, int *numClients, int clientID);
void removeProduct(Product *products, int *numProducts);
void managementMode(Product *products, int *numProducts, Client *clients, int *numClients);
void purchaseMode(Client *clients, int *numClients, Product *products, int *numProducts);
void underline(char *str);
void mainLoop(Product *products, int *numProducts, Client *clients, int *numClients);